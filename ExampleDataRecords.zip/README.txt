The example files must be unzipped before use with www.jsongrapher.com
JsonGrapher does not work if the input is still in a zip file.